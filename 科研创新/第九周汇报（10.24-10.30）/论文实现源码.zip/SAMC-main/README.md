## SAMC

Multiple Time Series Alignment for Learning Regression Model

+ `code/` includes the codes for experiments in python
+ `data/` includes the datasets used in experiments, the details and links of the datasets could be found in paper.
+ `proofs.pdf` provides all the proofs and additional experimental results. 

