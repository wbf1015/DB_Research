from .logistic import Logistic
from .naive_bayes import NaiveBayes


__all__ = ['Logistic', 'NaiveBayes']
