#!/usr/bin/env bash

# Set required environment variables.
source ../set_env.sh

# Launch tests.
echo "Launching tests..."
pytest -n 1
